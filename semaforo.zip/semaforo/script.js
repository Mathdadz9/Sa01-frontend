const vermelho = document.querySelector('.vermelho');
const amarelo = document.querySelector('.amarelo');
const verde = document.querySelector('.verde');
const botaoPedestre = document.getElementById("botaoPedestre");
const pedestre = document.getElementById("pedestre");

let intervaloId = null;
let pedestreEsperando = false;
let cicloAtivo = true;

function desligarLuzes() {
  vermelho.classList.remove('ativo');
  amarelo.classList.remove('ativo');
  verde.classList.remove('ativo');
}

function ligarVermelho() {
  desligarLuzes();
  vermelho.classList.add('ativo');
}

function ligarAmarelo() {
  desligarLuzes();
  amarelo.classList.add('ativo');
}

function ligarVerde() {
  desligarLuzes();
  verde.classList.add('ativo');
}

function iniciarSemaforo() {
  ligarVermelho();
  setTimeout(() => {
    if (cicloAtivo) {
      ligarVerde();
      setTimeout(() => {
        if (cicloAtivo) {
          ligarAmarelo();
          setTimeout(() => {
            if (cicloAtivo) iniciarSemaforo(); // Reinicia o ciclo
          }, 2000); // Tempo do amarelo
        }
      }, 3000); // Tempo do verde
    }
  }, 4000); // Tempo do vermelho
}

// Função para animar o pedestre atravessando
function atravessarRua() {
  pedestre.style.display = "block";
  pedestre.style.animation = "atravessar 5s linear forwards";

  setTimeout(() => {
    pedestre.style.display = "none";
    pedestre.style.animation = "";
  }, 5000);
}

// Inicia o ciclo do semáforo automaticamente
iniciarSemaforo();

// Ação do botão de pedestre
botaoPedestre.addEventListener("click", () => {
  if (pedestreEsperando) return; // Evita múltiplos cliques enquanto o pedestre está esperando

  pedestreEsperando = true;
  cicloAtivo = false; // Interrompe o ciclo do semáforo
  clearInterval(intervaloId); // Para o ciclo do semáforo
  desligarLuzes();
  ligarVermelho();

  atravessarRua();

  setTimeout(() => {
    pedestreEsperando = false;
    cicloAtivo = true; // Retorna a operação normal do semáforo
    iniciarSemaforo(); // Reinicia o ciclo após o pedestre atravessar
  }, 5000); // Espera 5 segundos para o pedestre atravessar
});
